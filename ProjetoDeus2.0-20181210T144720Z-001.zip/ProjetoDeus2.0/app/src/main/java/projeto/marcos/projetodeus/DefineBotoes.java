package projeto.marcos.projetodeus;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.view.MenuItem;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class DefineBotoes {

    public static void defineBottomNavigationBar(BottomNavigationViewEx bottomNavigationViewEx){

        bottomNavigationViewEx.setTextVisibility(false);

    }

    public static void defineNavegacao(final Context context, BottomNavigationViewEx viewEx){
        viewEx.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){

                    case R.id.Feed: context.startActivity(new Intent(context, Home_Activity.class));
                    break;
                }

                switch (item.getItemId()){

                    case R.id.Amigos: context.startActivity(new Intent(context, Amigos_Activity.class));
                        break;
                }

                switch (item.getItemId()){

                    case R.id.Postar: context.startActivity(new Intent(context, Postar_Activity.class));
                        break;
                }

                switch (item.getItemId()){

                    case R.id.Adicionar: context.startActivity(new Intent(context, Adicionar_Activity.class));
                        break;
                }

                switch (item.getItemId()){

                    case R.id.Perfil: context.startActivity(new Intent(context, Perfil_Activity.class));
                        break;
                }

                return false;
            }
        });
    }

}
