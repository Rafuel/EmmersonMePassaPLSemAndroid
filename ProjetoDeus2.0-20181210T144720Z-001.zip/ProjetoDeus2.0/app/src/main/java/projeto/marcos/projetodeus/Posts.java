package projeto.marcos.projetodeus;

public class Posts {

    public String nome, fotoPerfil, dia, hora, textoDoPost, uid;

    public Posts(){

    }

    public Posts(String nome, String fotoPerfil, String dia, String hora, String textoDoPost, String uid) {
        this.nome = nome;
        this.fotoPerfil = fotoPerfil;
        this.dia = dia;
        this.hora = hora;
        this.textoDoPost = textoDoPost;
        this.uid = uid;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(String fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getTextoDoPost() {
        return textoDoPost;
    }

    public void setTextoDoPost(String textoDoPost) {
        this.textoDoPost = textoDoPost;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
