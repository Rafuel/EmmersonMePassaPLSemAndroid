package projeto.marcos.projetodeus;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class Cadastro_Activity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;




    EditText Usuemail, Ususenha, Usuconfsenha;
    Button btnCadastrar;
    ProgressDialog janelaCarregam;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_);
        mAuth = FirebaseAuth.getInstance();


        Usuemail = findViewById(R.id.edEmail);
        Ususenha = findViewById(R.id.edtSenha);
        Usuconfsenha = findViewById(R.id.edtConfSenha);

        btnCadastrar = findViewById(R.id.btnCadastrar);
        janelaCarregam = new ProgressDialog(this);


        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CriaConta();
            }
        });

    }

    @Override
    protected void onStart(){
        super.onStart();
        FirebaseUser usuAtual = mAuth.getCurrentUser();
        if(usuAtual != null){
            HomeTela();
        }
    }


    private void CriaConta(){

        String email = Usuemail.getText().toString();
        String senha = Ususenha.getText().toString();
        String confSenha = Usuconfsenha.getText().toString();

        if (TextUtils.isEmpty(email)){
            Toast.makeText(this,"Informe um email", Toast.LENGTH_SHORT).show();
        }else if (TextUtils.isEmpty(senha)) {
            Toast.makeText(this, "Informe a senha", Toast.LENGTH_SHORT).show();
        }else if (TextUtils.isEmpty(confSenha)) {
            Toast.makeText(this, "Confirme a senha", Toast.LENGTH_SHORT).show();
        }else if(!senha.equals(confSenha)) {
            Toast.makeText(this, "As senhas devem ser iguais", Toast.LENGTH_SHORT).show();
        }else  {

            janelaCarregam.setTitle("Criando Conta");
            janelaCarregam.setMessage("Aguarde enquanto sua conta é criada");
            janelaCarregam.show();


            mAuth.createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        configUsuarioTela();
                        Toast.makeText(Cadastro_Activity.this, "Cadastro Efetuado", Toast.LENGTH_SHORT).show();
                        janelaCarregam.dismiss();
                }
                else{
                        String mensagem = task.getException().getMessage();
                        Toast.makeText(Cadastro_Activity.this, "Erro:"+ mensagem, Toast.LENGTH_SHORT).show();
                        janelaCarregam.dismiss();
                    }
            }

        });

        }
    }

    private void configUsuarioTela(){
        Intent intent = new Intent(Cadastro_Activity.this, ConfiguraUsuario.class);
        startActivity(intent);
        finish();
    }

    private void HomeTela(){
        Intent intent = new Intent(Cadastro_Activity.this, Home_Activity.class);
        startActivity(intent);
        finish();
    }





    public void onClick(View view) {
        finish();
    }

    }


