package projeto.marcos.projetodeus;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.collection.LLRBNode;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class Home_Activity extends AppCompatActivity {

    private DatabaseReference referenciaU;
    private FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_);
        mAuth = FirebaseAuth.getInstance();
        referenciaU = FirebaseDatabase.getInstance().getReference().child("Usuarios");
        setupNavigationIcon();

    }



    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null){
            Intent intent = new Intent(Home_Activity.this, MainActivity.class);
            startActivity(intent);
        }else{
             final String UidAtual = mAuth.getCurrentUser().getUid();
             referenciaU.addValueEventListener(new ValueEventListener() {
                 @Override
                 public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                     if (!dataSnapshot.hasChild(UidAtual)){
                         Intent intent = new Intent(Home_Activity.this, ConfiguraUsuario.class);
                         startActivity(intent);


                     }
                 }

                 @Override
                 public void onCancelled(@NonNull DatabaseError databaseError) {

                 }
             });

        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        }

    private void setupNavigationIcon(){

        BottomNavigationViewEx bottomNavigationViewEx = findViewById(R.id.botoes_navegacao);

       /* Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        DefineBotoes.defineBottomNavigationBar(bottomNavigationViewEx);
        DefineBotoes.defineNavegacao(Home_Activity.this, bottomNavigationViewEx);
*/


    }



}
