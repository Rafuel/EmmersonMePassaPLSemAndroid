package projeto.marcos.projetodeus;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

public class Postar_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_);


        setupNavigationIcon();
    }

    private void setupNavigationIcon(){

        BottomNavigationViewEx bottomNavigationViewEx = findViewById(R.id.botoes_navegacao);

        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        DefineBotoes.defineBottomNavigationBar(bottomNavigationViewEx);
        DefineBotoes.defineNavegacao(Postar_Activity.this, bottomNavigationViewEx);



    }

}
