package projeto.marcos.projetodeus;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class MainActivity extends AppCompatActivity {

    Button btnLogin;
    EditText edEmail, edSenha;
    ProgressDialog carregamento;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        carregamento = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();
        edEmail = findViewById(R.id.edEmail);
        edSenha = findViewById(R.id.edSenha);
        btnLogin = findViewById(R.id.btnLogar);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RealizaLogin();


            }
        });

    }

    @Override
    protected void onStart(){
        super.onStart();
        FirebaseUser usuAtual = mAuth.getCurrentUser();
        if(usuAtual != null){
            HomeTela();
        }
    }

    private void RealizaLogin(){

        String email = edEmail.getText().toString();
        String senha = edSenha.getText().toString();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(senha)){
            Toast.makeText(this, "Informe o login e a senha", Toast.LENGTH_SHORT).show();
        }else {

            carregamento.setTitle("Logando");
            carregamento.setMessage("Aguarde enquanto seus dados são checados");
            carregamento.show();


            mAuth.signInWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                         HomeTela();
                         Toast.makeText(MainActivity.this, "Sucesso!", Toast.LENGTH_SHORT).show();
                         carregamento.dismiss();
                    }else{
                        String mensagem = task.getException().getMessage();
                        Toast.makeText(MainActivity.this, "Erro:"+ mensagem, Toast.LENGTH_SHORT).show();
                        carregamento.dismiss();
                    }
            }
            });

        }
    }

    public void onClick(View view) {
        CadastroTela();
    }

    private void CadastroTela(){
        Intent intent = new Intent(MainActivity.this, Cadastro_Activity.class);
        startActivity(intent);
        finish();
    }

    private void HomeTela(){
        Intent intent = new Intent(MainActivity.this, Home_Activity.class);
        startActivity(intent);
        finish();
    }

}
