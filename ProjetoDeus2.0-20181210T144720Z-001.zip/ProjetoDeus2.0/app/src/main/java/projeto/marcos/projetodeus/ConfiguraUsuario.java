package projeto.marcos.projetodeus;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DialerFilter;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.CircleImageView;
import com.squareup.picasso.Picasso;
import java.util.HashMap;



public class ConfiguraUsuario extends AppCompatActivity {

    Button confDados;
    EditText Username, Nome, Descricao;
    CircleImageView fotoPerfil;
    String  idUsuAtual;
    ProgressDialog jCarregamento;
    private StorageReference UsFotoRef;
    final static int ponteiroGaleria = 1;
    private FirebaseAuth mAuth;
    private DatabaseReference UserRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configura_usuario);

        mAuth = FirebaseAuth.getInstance();
        UsFotoRef = FirebaseStorage.getInstance().getReference().child("ImagemDePefil");
        UserRef = FirebaseDatabase.getInstance().getReference().child("Usuarios");

        idUsuAtual = mAuth.getCurrentUser().getUid();
        confDados = findViewById(R.id.btnConfDados);
        Username = findViewById(R.id.edUsername);
        Nome = findViewById(R.id.edNome);
        Descricao = findViewById(R.id.edDescricao);
        fotoPerfil = findViewById(R.id.fotoPerfil);

        confDados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = Username.getText().toString();
                String nome = Nome.getText().toString();
                String descricao = Descricao.getText().toString();

                if (TextUtils.isEmpty(username) || TextUtils.isEmpty(nome) || TextUtils.isEmpty(descricao)){
                    Toast.makeText(ConfiguraUsuario.this, "Preencha todos os campos", Toast.LENGTH_SHORT ).show();
                }else {

                    jCarregamento.setTitle("Processamento de Dados");
                    jCarregamento.setMessage("Aguarde enquanto seus dados são assimilados");
                    jCarregamento.show();

                    HashMap mapaUsua = new HashMap();
                    mapaUsua.put("username", username);
                    mapaUsua.put("nome", nome);
                    mapaUsua.put("descricao", descricao);
                    UserRef.updateChildren(mapaUsua).addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful()){

                                HomeTela();
                                Toast.makeText(ConfiguraUsuario.this, "Assimilado!", Toast.LENGTH_SHORT).show();
                                jCarregamento.dismiss();

                            }else{

                                String mensagem = task.getException().getMessage();
                                Toast.makeText(ConfiguraUsuario.this, "Erro:" + mensagem, Toast.LENGTH_SHORT).show();
                                jCarregamento.dismiss();
                            }
                        }
                    });

                }
            }
        });


        fotoPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galeria = new Intent();
                galeria.setAction(Intent.ACTION_GET_CONTENT);
                galeria.setType("image/*");
                startActivityForResult(galeria, ponteiroGaleria);
            }
            });

        UserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.exists()){
                    if (dataSnapshot.hasChild("fotoPerfil")) {

                        String imagem = dataSnapshot.child("fotoPerfil").getValue().toString();

                        Picasso.get().load(imagem).into(fotoPerfil);
                    }

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ponteiroGaleria && resultCode == RESULT_OK && data!=null){
            Uri ImageUri = data.getData();
            CropImage.activity().setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1,1)
                    .start(this);
        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){

            CropImage.ActivityResult resultado = CropImage.getActivityResult(data);

            if(resultCode == RESULT_OK ){

                jCarregamento.setTitle("Imagem de Perfil");
                jCarregamento.setMessage("Aguarde enquanto sua imagem é assimilada");
                jCarregamento.show();


                Uri valorUri = resultado.getUri();
                StorageReference caminhoArq = UsFotoRef.child(idUsuAtual + ".jpg");

                caminhoArq.putFile(valorUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if(task.isSuccessful()){

                            Toast.makeText(ConfiguraUsuario.this, "Imagem assimilada", Toast.LENGTH_SHORT).show();

                            final String UrlBaixavel = task.getResult().getStorage().getDownloadUrl().toString();

                            UserRef.child("fotoPerfil").setValue(UrlBaixavel).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    if(task.isSuccessful()){

                                        Intent intent = new Intent(ConfiguraUsuario.this, ConfiguraUsuario.class);
                                        startActivity(intent);

                                        Toast.makeText(ConfiguraUsuario.this, "Imagem adicionada a matriz de dados", Toast.LENGTH_SHORT).show();
                                        jCarregamento.dismiss();

                                    }else{
                                        String mensagem = task.getException().getMessage();
                                        Toast.makeText(ConfiguraUsuario.this, "Erro:" + mensagem, Toast.LENGTH_SHORT).show();
                                        jCarregamento.dismiss();
                                    }

                                }
                            });


                        }
                    }
                });
            }else{

                Toast.makeText(this, "Erro na imagem, tente novamente", Toast.LENGTH_SHORT).show();

            }
        }
    }

    private void HomeTela(){
        Intent intent = new Intent(ConfiguraUsuario.this, Home_Activity.class);
        startActivity(intent);
        finish();
    }

}
